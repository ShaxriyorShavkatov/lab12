@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private UserProfileRepository profileRepository;
    
    @PostMapping
    public User createUser(@RequestBody User user) {
        if (user.getProfile() != null) {
            profileRepository.save(user.getProfile());
        }
        return userRepository.save(user);
    }
    
    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    @GetMapping("/{id}")
    public User getUserById(@PathVariable String id) {
        return userRepository.findById(id).orElseThrow(() ->
            new RuntimeException("Not Found"));
    }
}

