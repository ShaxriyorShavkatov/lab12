ALTER TABLE employee ADD COLUMN department VARCHAR(255);

