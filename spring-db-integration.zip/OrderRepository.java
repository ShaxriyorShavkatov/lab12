@Repository
public interface OrderRepository extends MongoRepository<Order, String> {
    @Aggregation(pipeline = {
        "{ $group: { _id: null, total: { $sum: '$totalAmount' } } }"
    })
    Double getTotalOrderValue();
    
    @Aggregation(pipeline = {
        "{ $match: { 'status': ?0 } }",
        "{ $group: { _id: null, total: { $sum: '$totalAmount' } } }"
    })
    Double getTotalOrderValueByStatus(String status);
    
    @Aggregation(pipeline = {
        "{ $match: { 'customerId': ?0 } }",
        "{ $group: { _id: null, total: { $sum: '$totalAmount' } } }"
    })
    Double getTotalOrderValueByCustomer(String customerId);
}

