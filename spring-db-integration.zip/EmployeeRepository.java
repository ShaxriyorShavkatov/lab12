@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findBySalaryGreaterThan(Double threshold);
    List<Employee> findBySalaryLessThan(Double threshold);
}

