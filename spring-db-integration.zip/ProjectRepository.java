@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findByDescriptionContaining(String keyword);
}

