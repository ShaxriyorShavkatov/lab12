@Repository
public interface UserProfileRepository extends MongoRepository<UserProfile, String> {}

