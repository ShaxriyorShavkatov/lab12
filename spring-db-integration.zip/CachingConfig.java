@Configuration
@EnableCaching
public class CachingConfig {
    @Bean
    public CacheManager cacheManager() {
        SimpleCacheManager cacheManager = new SimpleCacheManager();
        cacheManager.setCaches(Arrays.asList(
            new ConcurrentMapCache("projects"),
            new ConcurrentMapCache("projectsByDescription")
        ));
        return cacheManager;
    }
}

