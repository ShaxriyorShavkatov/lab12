@RestController
@RequestMapping("/projects")
public class ProjectController {
    @Autowired
    private ProjectService service;
    
    @PostMapping
    public Project createProject(@RequestBody Project project) {
        return service.saveProject(project);
    }
    
    @GetMapping
    public List<Project> getAllProjects() {
        return service.getAllProjects();
    }
    
    @GetMapping("/{id}")
    public Project getProjectById(@PathVariable Long id) {
        return service.getProjectById(id);
    }
    
    @GetMapping("/search")
    public List<Project> searchProjects(@RequestParam String keyword) {
        return service.findByDescriptionContaining(keyword);
    }
    
    @PutMapping("/{id}")
    public Project updateProject(@PathVariable Long id, @RequestBody Project project) {
        project.setId(id);
        return service.saveProject(project);
    }
    
    @DeleteMapping("/{id}")
    public void deleteProject(@PathVariable Long id) {
        service.deleteProject(id);
    }
}

