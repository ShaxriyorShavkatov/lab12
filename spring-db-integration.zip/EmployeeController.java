@GetMapping("/by-salary")
public List<Employee> getEmployeesBySalary(
        @RequestParam String comparison,
        @RequestParam Double threshold) {
    
    if ("greater".equals(comparison)) {
        return repository.findBySalaryGreaterThan(threshold);
    } else {
        return repository.findBySalaryLessThan(threshold);
    }
}

