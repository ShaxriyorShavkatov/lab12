@RestController
@RequestMapping("/customers")
public class CustomerController {
    @Autowired
    private CustomerRepository repository;
    
    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        return repository.save(customer);
    }
    
    @GetMapping
    public List<Customer> getAllCustomers() {
        return repository.findAll();
    }
    
    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        return repository.findById(id)
        .orElseThrow(() -> new CustomerNotFoundException(id));
    }

    @GetMapping("/by-region")
    public List<Customer> getCustomersByRegion(@RequestParam String region) {
        return repository.findByRegion(region);
    }
    
    @PutMapping("/{id}")
    public Customer updateCustomer(@PathVariable Long id, @RequestBody Customer customer) {
        customer.setId(id);
        return repository.save(customer);
    }
    
    @DeleteMapping("/{id}")
    public void deleteCustomer(@PathVariable Long id) {
        repository.deleteById(id);
    }
}

