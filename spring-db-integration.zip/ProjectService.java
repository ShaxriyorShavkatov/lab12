@Service
public class ProjectService {
    @Autowired
    private ProjectRepository repository;
    
    @Cacheable("projects")
    public List<Project> getAllProjects() {
        return repository.findAll();
    }
    
    @Cacheable("projects")
    public Project getProjectById(Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Project not found"));
    }
    
    @Cacheable("projectsByDescription")
    public List<Project> findByDescriptionContaining(String keyword) {
        return repository.findByDescriptionContaining(keyword);
    }
    
    @CacheEvict(value = "projects", allEntries = true)
    public Project saveProject(Project project) {
        return repository.save(project);
    }
    
    @CacheEvict(value = "projects", allEntries = true)
    public void deleteProject(Long id) {
        repository.deleteById(id);
    }
}

