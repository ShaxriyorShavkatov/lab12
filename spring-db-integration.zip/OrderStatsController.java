@RestController
@RequestMapping("/order-stats")
public class OrderStatsController {
    @Autowired
    private OrderRepository repository;
    
    @GetMapping("/total-value")
    public Map<String, Double> getTotalOrderValue() {
        Double total = repository.getTotalOrderValue();
        return Collections.singletonMap("totalValue", total != null ? total : 0.0);
    }
    
    @GetMapping("/total-by-status")
    public Map<String, Double> getTotalOrderValueByStatus(@RequestParam String status) {
        Double total = repository.getTotalOrderValueByStatus(status);
        return Collections.singletonMap("totalValue", total != null ? total : 0.0);
    }
    
    @GetMapping("/total-by-customer/{customerId}")
    public Map<String, Double> getTotalOrderValueByCustomer(@PathVariable String customerId) {
        Double total = repository.getTotalOrderValueByCustomer(customerId);
        return Collections.singletonMap("totalValue", total != null ? total : 0.0);
    }
}

