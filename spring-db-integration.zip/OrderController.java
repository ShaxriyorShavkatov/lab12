@GetMapping("/filter")
public List<Order> filterOrders(
        @RequestParam(required = false) String status,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {
    
    if (status != null) {
        return repository.findByStatusAndOrderDateBetween(status, startDate, endDate);
    } else {
        return repository.findByOrderDateBetween(startDate, endDate);
    }
}

