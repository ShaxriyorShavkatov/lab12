@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {}

