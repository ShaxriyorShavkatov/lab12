@Repository
public interface UserRepository extends MongoRepository<User, String> {}

