@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {}

